<?php

class Home extends CI_Controller
{
    public function index()
    {
        $data['title'] = "Home";
        $this->load->view('layout/header', $data);
        $this->load->view('home/home');
        $this->load->view('layout/footer');
    }

    public function voter()
}
