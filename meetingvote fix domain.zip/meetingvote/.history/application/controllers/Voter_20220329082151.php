<?php

class Voter extends CI_Controller
{
    public function index()
    {
        $data['title'] = "Home";
        $this->load->view('layout/header', $data);
        $this->load->view('voter/voter');
        $this->load->view('layout/footer');
    }

    public function tambah()
    {
        $data['title'] = "Tambah Acara";
        $this->load->view('layout/header', $data);
        $this->load->view('voter/tambah');
        $this->load->view('layout/footer');
    }

    public function simpan()
    {
        $link = uniqid();
        $data = [
            'nama_event' => $this->input->post('nama_event', true),
            'tanggal_1' => date('Y-m-d H:i:s', strtotime($this->input->post('tanggal_1'))),
            'tanggal_2' => date('Y-m-d H:i:s', strtotime($this->input->post('tanggal_2'))),
            'tanggal_3' => date('Y-m-d H:i:s', strtotime($this->input->post('tanggal_3'))),
            'link' => $link
        ];

        $id = $this->input->post('id');

        $this->db->insert('events', $data);

        $this->session->set_flashdata('notif', "
            <script>
                Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Tambah data acara berhasil',
                showConfirmButton: false,
                timer: 1500
                })
            </script>
            ");

        redirect('voter/link/' . $link);
    }

    public function link($link)
    {
        $data['title'] = "Link Page";
        $data['link'] = $link;
        $this->load->view('layout/header', $data);
        $this->load->view('voter/link');
        $this->load->view('layout/footer');
    }

    public function voters($link)
    {
        $data['title'] = "Voters";
        $data['events'] = $this->db->query("SELECT * FROM events WHERE link='$link'")->row_array();
        $this->load->view('layout/header', $data);
        $this->load->view('voter/voters');
        $this->load->view('layout/footer');
    }

    public function vote(){
        $data = [
            'nama_event' => $this->input->post('nama_event', true),
            'tanggal_1' => date('Y-m-d H:i:s', strtotime($this->input->post('tanggal_1'))),
            'tanggal_2' => date('Y-m-d H:i:s', strtotime($this->input->post('tanggal_2'))),
            'tanggal_3' => date('Y-m-d H:i:s', strtotime($this->input->post('tanggal_3'))),
            'link' => $link
        ];

        $id = $this->input->post('id');

        $this->db->insert('events', $data);

        $this->session->set_flashdata('notif', "
            <script>
                Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Tambah data acara berhasil',
                showConfirmButton: false,
                timer: 1500
                })
            </script>
            ");

        redirect('voter');
    }
}
