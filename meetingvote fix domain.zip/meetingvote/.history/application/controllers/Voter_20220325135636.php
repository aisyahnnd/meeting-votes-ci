<?php

class Voter extends CI_Controller
{
    public function index()
    {
        redirect('home');
        $data['title'] = "Home";
        $this->load->view('home/home', $data);
    }
}
