<?php

class Voter extends CI_Controller
{
    public function index()
    {
        $data['title'] = "Home";
        $this->load->view('layout/header', $data);
        $this->load->view('voter/voter');
        $this->load->view('layout/footer');
    }

    public function tambah()
    {
        $data['title'] = "Tambah Acara";
        $this->load->view('layout/header', $data);
        $this->load->view('voter/tambah');
        $this->load->view('layout/footer');
    }

    public function simpan()
    {
        $data = [
            'nama_event' => $this->input->post('nama_event', true),
            'tanggal_1' => date('Y-m-d H:i:s'),
            'tanggal_2' => date('Y-m-d H:i:s'),
            'tanggal_3' => date('Y-m-d H:i:s'),
            'link' => $this->input->post('link', true)
        ];

        // $id = $this->input->post('id');

        $this->db->insert('event', $data);

        $this->session->set_flashdata('notif', "
            <script>
                Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Tambah data acara berhasil',
                showConfirmButton: false,
                timer: 1500
                })
            </script>
            ");

        redirect('voter/link');
    }

    public function link()
    {
        $data['title'] = "Link Page";
        $this->load->view('layout/header', $data);
        $this->load->view('voter/link');
        $this->load->view('layout/footer');
    }

    public function voters($id)
    {
        $data['title'] = "Voters";
        $data['event'] = $this->db->query("SELECT * FROM pegawai WHERE id='$id'")->row_array();
        $this->load->view('layout/header', $data);
        $this->load->view('voter/voters');
        $this->load->view('layout/footer');
    }
}
