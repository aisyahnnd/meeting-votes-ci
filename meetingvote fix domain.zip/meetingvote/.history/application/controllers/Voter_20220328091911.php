<?php

class Voter extends CI_Controller
{
    public function index()
    {
        $data['title'] = "Home";
        $this->load->view('layout/header', $data);
        $this->load->view('voter/tambah');
        $this->load->view('layout/footer');
    }

    public function tambah()
    {
        $data['title'] = "Tambah Acara";
        $this->load->view('layout/header', $data);
        $this->load->view('voter/tambah');
        $this->load->view('layout/footer');
    }

    public function simpan()
    {
        $data = [
            'nama_event' => $this->input->post('nama_event', true),
            'nama_event' => date('d-m-Y H:i'),
            'nama_event' => date('Y-m-d H:i'),
            'nama_event' => date('Y-m-d H:i'),
            'nama' => $this->input->post('nama', true),
            'nip' => $this->input->post('nip', true),
            'hp' => $this->input->post('hp', true),
            'wilayah' => $this->input->post('provinsi', true)
        ];

        $id = $this->input->post('id');

        if ($id) {
            // Update Data
            $this->db->where('id', $id)->update('pegawai', $data);

            $this->session->set_flashdata('notif', "
            <script>
                Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Update data pegawai berhasil',
                showConfirmButton: false,
                timer: 1500
                })
            </script>
            ");
        } else {
            // Tambah Data
            $this->db->insert('pegawai', $data);

            $this->session->set_flashdata('notif', "
            <script>
                Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Tambah data pegawai berhasil',
                showConfirmButton: false,
                timer: 1500
                })
            </script>
            ");
        }

        redirect('pegawai');
    }
}
