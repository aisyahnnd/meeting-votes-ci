<?php

class Voter extends CI_Controller
{
    public function index()
    {
    }
}
