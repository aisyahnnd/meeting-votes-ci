<?php

class Voter extends CI_Controller
{
    public function index()
    {
        $data['title'] = "Home";
        $this->load->view('layout/header', $data);
        $this->load->view('voter/tambah');
        $this->load->view('layout/footer');
    }

    public function tambah()
    {
        $data['title'] = "Tambah Acara";
        $this->load->view('layout/header', $data);
        $this->load->view('voter/tambah');
        $this->load->view('layout/footer');
    }

    public function simpan()
    {
        $data = [
            'nama_event' => $this->input->post('nama_event', true),
            'nama_event' => date('d-m-Y H:i'),
            'nama_event' => date('d-m-Y H:i'),
            'nama_event' => date('d-m-Y H:i'),
            'link' => $this->input->post('link', true)
        ];

        $id = $this->input->post('id');

        

        redirect('pegawai');
    }
}
