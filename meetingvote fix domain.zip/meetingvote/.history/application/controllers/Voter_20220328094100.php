<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Voter extends CI_Controller
{
    public function index()
    {
        $data['title'] = "Home";
        $this->load->view('layout/header', $data);
        $this->load->view('voter/voter');
        $this->load->view('layout/footer');
    }

    public function tambah()
    {
        $data['title'] = "Tambah Acara";
        $this->load->view('layout/header', $data);
        $this->load->view('voter/tambah');
        $this->load->view('layout/footer');
    }

    public function simpan()
    {
        $data = [
            'nama_event' => $this->input->post('nama_event', true),
            'tanggal_1' => date('d-m-Y H:i'),
            'tanggal_1' => date('d-m-Y H:i'),
            'nama_event' => date('d-m-Y H:i'),
            'link' => $this->input->post('link', true)
        ];

        // $id = $this->input->post('id');

        $this->db->insert('event', $data);

        $this->session->set_flashdata('notif', "
            <script>
                Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Tambah data acara berhasil',
                showConfirmButton: false,
                timer: 1500
                })
            </script>
            ");

        redirect('voter');
    }
}
